package com.testonline.service;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.testonline.dao.dao;
import com.testonline.hibernate.Student;
import com.testonline.hibernate.Test;
/*
 * @service��עҵ������
 * @Transactional��ע�������
 * 
 */


@Service("service")
@Transactional(readOnly=false)
public class serviceImpl implements service {
	@Resource(name="dao")
	private dao dao;
	//��ֵע��
	public dao getDao() {
		return dao;
	}


	public void setDao(dao dao) {
		this.dao = dao;
	}

	//��д����
	@Override
	public Student checkname(String name) {
		Student str = this.dao.checkname(name);
		return str;
	}
	//��д����
	@Override
	public List<Test> findtest(String course,int pageNow, int pageSize) {
		List<Test> list = this.dao.findtest(course,pageNow,pageSize);
		return list;
	}


	@Override
	public Test checkanswer(int s) {
		Test t = this.dao.checkanswer(s);
		return t;
	}


	
}
