package com.testonline.hibernate;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="test")
public class Test {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "testID")
	private int testID;
	private String title;
	private String answer;
	private String A;
	private String B;
	private String C;
	private String D;
	//@Basic��ץȡ����
	//JoinColumҪ��Course�ж�Ӧ
	@ManyToOne
	@JoinColumn(name="course_ID")
	@Basic(fetch=FetchType.LAZY)
	private Course course;
	
	public Course getCourse() {
		return course;
	}
	public void setCourseID(Course course) {
		this.course= course;
	}
	public int getTestID() {
		return testID;
	}
	public void setTestID(int testID) {
		this.testID = testID;
	}
	public String getA() {
		return A;
	}
	public void setA(String a) {
		A = a;
	}
	public String getB() {
		return B;
	}
	public void setB(String b) {
		B = b;
	}
	public String getC() {
		return C;
	}
	public void setC(String c) {
		C = c;
	}
	public String getD() {
		return D;
	}
	public void setD(String d) {
		D = d;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
	
	
}
