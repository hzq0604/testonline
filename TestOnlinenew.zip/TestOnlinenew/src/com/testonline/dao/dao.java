package com.testonline.dao;


import java.util.List;

import com.testonline.hibernate.Student;
import com.testonline.hibernate.Test;

public interface dao{

	Student checkname(String name);

	List<Test> findtest(String course, int pageNow, int pageSize);

	Test checkanswer(int s);


}
